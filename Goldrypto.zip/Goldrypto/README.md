# Goldrypto

## Prerequisites

- Node.js
- Docker
- TronLink Wallet

## Setup

1. Clone the repository:

   ```bash
   git clone <repository-url>
   cd Goldrypto
   ```

2. Update the `tronbox.js` file with your private key.

3. Build and run the Docker containers:

   ```bash
   docker-compose build
   docker-compose up
   ```

4. Open the frontend application at `http://localhost:3001`.

## Configuration

- `tronbox.js`: Update with your TRON private key and network configuration.
- `src/backend/server.js`: Backend service for handling transactions.
- `src/frontend/src/App.js`: Frontend React application for interacting with the smart contract.

## Deployment

Ensure that you have all the dependencies and configurations set up correctly. Then follow the setup instructions to deploy and run the application.