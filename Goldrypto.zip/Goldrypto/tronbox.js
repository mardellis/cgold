module.exports = {
  networks: {
    development: {
      privateKey: 'YOUR_PRIVATE_KEY', // Update this with your private key
      consume_user_resource_percent: 30,
      fee_limit: 1e9,
      fullNode: "http://127.0.0.1:9090",
      solidityNode: "http://127.0.0.1:9090",
      eventServer: "http://127.0.0.1:9090",
      network_id: "*"
    }
  },
  compilers: {
    solc: {
      version: "0.5.4"
    }
  }
};