import React, { useState } from 'react';
import TronWeb from 'tronweb';

const App = () => {
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');

  const handleTransaction = async () => {
    const tronWeb = new TronWeb({
      fullHost: 'http://127.0.0.1:9090'
    });

    try {
      const tx = await tronWeb.trx.sendTransaction(address, amount);
      setMessage(`Transaction successful: ${tx.txID}`);
    } catch (error) {
      setMessage(`Transaction failed: ${error.message}`);
    }
  };

  return (
    <div>
      <h1>Goldrypto</h1>
      <input
        type="text"
        placeholder="Recipient Address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />
      <input
        type="number"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <button onClick={handleTransaction}>Send Transaction</button>
      <p>{message}</p>
    </div>
  );
};

export default App;