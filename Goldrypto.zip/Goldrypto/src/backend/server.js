const express = require('express');
const bodyParser = require('body-parser');
const TronWeb = require('tronweb');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const fullNode = 'http://127.0.0.1:9090';
const solidityNode = 'http://127.0.0.1:9090';
const eventServer = 'http://127.0.0.1:9090';
const privateKey = 'YOUR_PRIVATE_KEY'; // Update this with your private key

const tronWeb = new TronWeb(fullNode, solidityNode, eventServer, privateKey);

app.post('/transaction', async (req, res) => {
  const { to, amount } = req.body;
  try {
    const tx = await tronWeb.trx.sendTransaction(to, amount);
    res.json(tx);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});