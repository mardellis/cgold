const Goldrypto = artifacts.require("Goldrypto");

module.exports = function(deployer) {
  deployer.deploy(Goldrypto, "Goldrypto", "GLD", 18, 1000000);
};